# Intake Service Starter

A small FastAPI starter for the first phase of your AI receptionist MVP.

## What this does

- Starts an intake session
- Collects required fields with a simple state machine
- Builds a structured ticket
- Confirms details before submission
- Optionally forwards the confirmed ticket to an OpenClaw webhook adapter

## File layout

```text
app/
  config.py
  extraction.py
  main.py
  models.py
  opencaw_adapter.py
  state_machine.py
scripts/
  run_dev.sh
requirements.txt
.env.example
```

## Quick start

```bash
cd intake-service-starter
cp .env.example .env
./scripts/run_dev.sh
```

Open the API docs at:

```text
http://127.0.0.1:8000/docs
```

## Example flow

### 1. Start a session

```bash
curl -X POST http://127.0.0.1:8000/sessions \
  -H 'Content-Type: application/json' \
  -d '{"phone":"+14155551234"}'
```

### 2. Provide name

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"Hi, my name is Connor"}'
```

### 3. Provide service

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"I need an oil change"}'
```

### 4. Provide time

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"Tuesday morning works"}'
```

### 5. Optional notes

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"It is for a Honda Civic"}'
```

### 6. Confirm

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"yes"}'
```

## Notes

This is intentionally simple:

- in-memory sessions only
- no real telephony yet
- no database yet
- OpenClaw forwarding is optional and can stay disabled while you build the intake flow

## Suggested next steps

1. Persist sessions in SQLite or Postgres
2. Add a real telephony webhook layer
3. Add stronger field extraction and confidence scores
4. Add a business-specific schema per vertical
5. Add OpenClaw webhook auth and a dedicated low-privilege hook agent
