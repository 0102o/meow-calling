from __future__ import annotations

from typing import Dict

from fastapi import FastAPI, HTTPException

from .config import get_settings
from .models import (
    HealthResponse,
    IntakeSession,
    StartSessionRequest,
    StartSessionResponse,
    UserTurnRequest,
    UserTurnResponse,
)
from .opencaw_adapter import submit_ticket
from .state_machine import IntakeStateMachine

app = FastAPI(title="Intake Service", version="0.1.0")
settings = get_settings()
state_machine = IntakeStateMachine()
SESSIONS: Dict[str, IntakeSession] = {}


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@app.post("/sessions", response_model=StartSessionResponse)
def start_session(body: StartSessionRequest) -> StartSessionResponse:
    session = IntakeSession()
    if body.phone:
        session.ticket.customer.phone = body.phone
    message = state_machine.start_message()
    session.state = session.state.COLLECT_NAME
    session.last_assistant_message = message
    session.touch()
    SESSIONS[session.session_id] = session
    return StartSessionResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=message,
        ticket=session.ticket,
    )


@app.get("/sessions/{session_id}", response_model=UserTurnResponse)
def get_session(session_id: str) -> UserTurnResponse:
    session = SESSIONS.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return UserTurnResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=session.last_assistant_message or state_machine.start_message(),
        ticket=session.ticket,
        submitted_to_openclaw=session.submitted_to_openclaw,
        openclaw_response=session.openclaw_response,
    )


@app.post("/sessions/{session_id}/turn", response_model=UserTurnResponse)
async def user_turn(session_id: str, body: UserTurnRequest) -> UserTurnResponse:
    session = SESSIONS.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    message = state_machine.handle_turn(session, body.user_input)
    session.last_assistant_message = message

    if session.state.value == "submitted" and not session.submitted_to_openclaw:
        submission_result = await submit_ticket(session.ticket, settings)
        session.submitted_to_openclaw = submission_result.submitted
        session.openclaw_response = submission_result.response
        session.ticket.status = "submitted_to_openclaw" if submission_result.submitted else "confirmed_local"
        session.last_assistant_message = (
            "Thanks. Your request has been submitted. "
            "We'll follow up with the next step shortly."
        )
        session.touch()

    return UserTurnResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=session.last_assistant_message,
        ticket=session.ticket,
        submitted_to_openclaw=session.submitted_to_openclaw,
        openclaw_response=session.openclaw_response,
    )
