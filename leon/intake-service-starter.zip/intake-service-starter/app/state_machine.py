from __future__ import annotations

from .extraction import apply_extractions
from .models import IntakeSession, SessionState


class IntakeStateMachine:
    def start_message(self) -> str:
        return (
            "Hi, thanks for calling. I can help start your request. "
            "May I have your name?"
        )

    def handle_turn(self, session: IntakeSession, user_input: str) -> str:
        text = user_input.strip()
        if not text:
            return "I didn't catch that. Could you say that one more time?"

        current_state = session.state
        collect_notes = current_state == SessionState.COLLECT_NOTES
        apply_extractions(session.ticket, text, collect_notes=collect_notes)

        if current_state == SessionState.CONFIRMATION:
            return self._handle_confirmation(session, text)
        if current_state == SessionState.CORRECTION:
            return self._handle_correction(session, text)

        next_state = self._resolve_state(session)
        session.state = next_state
        session.touch()
        return self._message_for_state(session)

    def _resolve_state(self, session: IntakeSession) -> SessionState:
        ticket = session.ticket
        if not ticket.customer.name:
            return SessionState.COLLECT_NAME
        if not ticket.request.service:
            return SessionState.COLLECT_SERVICE
        if not ticket.request.preferred_time:
            return SessionState.COLLECT_TIME
        if session.state in {SessionState.COLLECT_NOTES, SessionState.COLLECT_TIME} and ticket.request.notes is None:
            return SessionState.COLLECT_NOTES
        return SessionState.CONFIRMATION

    def _message_for_state(self, session: IntakeSession) -> str:
        ticket = session.ticket
        state = session.state
        if state == SessionState.COLLECT_NAME:
            return "Thanks. May I have your name?"
        if state == SessionState.COLLECT_SERVICE:
            return f"Thanks{_name_suffix(ticket.customer.name)}. What service do you need?"
        if state == SessionState.COLLECT_TIME:
            return "What time works best for you?"
        if state == SessionState.COLLECT_NOTES:
            return "Any notes you'd like me to add before I confirm? You can also say no."
        if state == SessionState.CONFIRMATION:
            summary = self._build_summary(ticket)
            return f"Let me confirm: {summary}. Is that correct?"
        if state == SessionState.SUBMITTED:
            return "Thanks. Your request has been submitted."
        return self.start_message()

    def _handle_confirmation(self, session: IntakeSession, text: str) -> str:
        lowered = text.lower()
        if lowered in {"yes", "y", "correct", "that's correct", "thats correct", "looks good"}:
            session.state = SessionState.SUBMITTED
            session.ticket.status = "confirmed"
            session.touch()
            return "Perfect. I have your request and I'm submitting it now."

        if lowered in {"no", "n", "not correct", "change it"}:
            session.state = SessionState.CORRECTION
            session.touch()
            return "No problem. What would you like to change: name, service, time, or notes?"

        return "Please say yes if the details are correct, or no if you'd like to change something."

    def _handle_correction(self, session: IntakeSession, text: str) -> str:
        lowered = text.lower()
        ticket = session.ticket

        if "name" in lowered:
            ticket.customer.name = None
            session.state = SessionState.COLLECT_NAME
            session.touch()
            return "Okay, let's update your name. What name should I use?"
        if "service" in lowered:
            ticket.request.service = None
            session.state = SessionState.COLLECT_SERVICE
            session.touch()
            return "Okay, what service do you need?"
        if "time" in lowered or "date" in lowered:
            ticket.request.preferred_time = None
            session.state = SessionState.COLLECT_TIME
            session.touch()
            return "Okay, what time works best for you?"
        if "note" in lowered:
            ticket.request.notes = None
            session.state = SessionState.COLLECT_NOTES
            session.touch()
            return "Okay, what notes would you like me to add?"

        apply_extractions(ticket, text, collect_notes=True)
        session.state = self._resolve_state(session)
        session.touch()
        return self._message_for_state(session)

    def _build_summary(self, ticket) -> str:
        parts = [
            f"name {ticket.customer.name}",
            f"service {ticket.request.service}",
            f"preferred time {ticket.request.preferred_time}",
        ]
        if ticket.request.notes:
            parts.append(f"notes {ticket.request.notes}")
        return ", ".join(parts)



def _name_suffix(name: str | None) -> str:
    return f", {name}" if name else ""
