from __future__ import annotations

import re
from typing import Optional

from .models import Ticket

SERVICE_KEYWORDS = [
    "oil change",
    "tire rotation",
    "brake inspection",
    "haircut",
    "consultation",
    "cleaning",
    "repair",
    "appointment",
    "estimate",
]

TIME_PATTERNS = [
    r"\btomorrow(?: morning| afternoon| evening)?\b",
    r"\btoday(?: morning| afternoon| evening)?\b",
    r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)(?: morning| afternoon| evening)?\b",
    r"\b\d{1,2}(?::\d{2})?\s?(?:am|pm)\b",
    r"\bmorning\b",
    r"\bafternoon\b",
    r"\bevening\b",
    r"\bnext week\b",
]

NAME_PATTERNS = [
    r"(?:my name is|this is|i am|i'm)\s+([A-Za-z][A-Za-z\-']+(?:\s+[A-Za-z][A-Za-z\-']+)?)",
]

PHONE_PATTERN = re.compile(r"(?:\+?1[-.\s]?)?(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})")


def extract_name(text: str) -> Optional[str]:
    for pattern in NAME_PATTERNS:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return _title_clean(match.group(1))

    cleaned = text.strip()
    if 1 <= len(cleaned.split()) <= 3 and cleaned.replace(" ", "").replace("-", "").isalpha():
        return _title_clean(cleaned)
    return None



def extract_service(text: str) -> Optional[str]:
    lowered = text.lower()
    for keyword in SERVICE_KEYWORDS:
        if keyword in lowered:
            return keyword

    service_match = re.search(r"(?:need|want|book|schedule|get)\s+(?:an?\s+)?(.+?)(?:\s+(?:for|on|at|tomorrow|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b|$)", lowered)
    if service_match:
        candidate = service_match.group(1).strip(" .,!?")
        if 1 <= len(candidate.split()) <= 6:
            return candidate
    return None



def extract_preferred_time(text: str) -> Optional[str]:
    lowered = text.lower()
    for pattern in TIME_PATTERNS:
        match = re.search(pattern, lowered, flags=re.IGNORECASE)
        if match:
            return match.group(0).strip()

    time_match = re.search(r"(?:for|on|at)\s+(.+)$", lowered)
    if time_match:
        candidate = time_match.group(1).strip(" .,!?")
        if 1 <= len(candidate.split()) <= 6:
            return candidate
    return None



def extract_phone(text: str) -> Optional[str]:
    match = PHONE_PATTERN.search(text)
    if not match:
        return None
    digits = re.sub(r"\D", "", match.group(1))
    if len(digits) == 10:
        return f"+1{digits}"
    return None



def apply_extractions(ticket: Ticket, text: str, collect_notes: bool = False) -> None:
    name = extract_name(text)
    service = extract_service(text)
    preferred_time = extract_preferred_time(text)
    phone = extract_phone(text)

    if name and not ticket.customer.name:
        ticket.customer.name = name
    if service and not ticket.request.service:
        ticket.request.service = service
    if preferred_time and not ticket.request.preferred_time:
        ticket.request.preferred_time = preferred_time
    if phone and not ticket.customer.phone:
        ticket.customer.phone = phone

    if collect_notes:
        stripped = text.strip()
        if stripped and stripped.lower() not in {"no", "none", "nope", "nothing", "that's all", "thats all"}:
            ticket.request.notes = stripped



def _title_clean(value: str) -> str:
    return " ".join(part.capitalize() for part in value.strip().split())
