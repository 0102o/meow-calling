from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class SessionState(str, Enum):
    GREETING = "greeting"
    COLLECT_NAME = "collect_name"
    COLLECT_SERVICE = "collect_service"
    COLLECT_TIME = "collect_time"
    COLLECT_NOTES = "collect_notes"
    CONFIRMATION = "confirmation"
    CORRECTION = "correction"
    SUBMITTED = "submitted"


class Customer(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None


class RequestDetails(BaseModel):
    intent: str = "appointment_request"
    service: Optional[str] = None
    preferred_time: Optional[str] = None
    notes: Optional[str] = None


class Ticket(BaseModel):
    ticket_id: str = Field(default_factory=lambda: f"tk_{uuid4().hex[:10]}")
    channel: str = "phone"
    customer: Customer = Field(default_factory=Customer)
    request: RequestDetails = Field(default_factory=RequestDetails)
    status: str = "draft"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def touch(self) -> None:
        self.updated_at = datetime.now(timezone.utc)


class IntakeSession(BaseModel):
    session_id: str = Field(default_factory=lambda: f"sess_{uuid4().hex[:10]}")
    state: SessionState = SessionState.GREETING
    ticket: Ticket = Field(default_factory=Ticket)
    last_assistant_message: Optional[str] = None
    submitted_to_openclaw: bool = False
    openclaw_response: Optional[dict] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def touch(self) -> None:
        self.updated_at = datetime.now(timezone.utc)
        self.ticket.touch()


class StartSessionRequest(BaseModel):
    phone: Optional[str] = None


class StartSessionResponse(BaseModel):
    session_id: str
    state: SessionState
    assistant_message: str
    ticket: Ticket


class UserTurnRequest(BaseModel):
    user_input: str


class UserTurnResponse(BaseModel):
    session_id: str
    state: SessionState
    assistant_message: str
    ticket: Ticket
    submitted_to_openclaw: bool = False
    openclaw_response: Optional[dict] = None


class HealthResponse(BaseModel):
    status: str


class OpenClawSubmissionResult(BaseModel):
    submitted: bool
    payload: dict
    response: Optional[dict] = None
