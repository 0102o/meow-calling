from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Optional

from .models import IntakeSession, TicketDetail, TicketSummary


def get_connection(db_path: str) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            state TEXT NOT NULL,
            ticket_id TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tickets (
            ticket_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            status TEXT NOT NULL,
            customer_name TEXT,
            service TEXT,
            preferred_time TEXT,
            submitted_to_openclaw INTEGER NOT NULL DEFAULT 0,
            openclaw_response_json TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(session_id) REFERENCES sessions(session_id)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tickets_session_id ON tickets(session_id)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tickets_updated_at ON tickets(updated_at DESC)"
    )
    conn.commit()


class SessionRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def save_session(self, session: IntakeSession) -> None:
        session_json = json.dumps(session.model_dump(mode="json"))
        ticket = session.ticket
        ticket_json = json.dumps(ticket.model_dump(mode="json"))
        self.conn.execute(
            """
            INSERT INTO sessions (session_id, state, ticket_id, payload_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
                state=excluded.state,
                ticket_id=excluded.ticket_id,
                payload_json=excluded.payload_json,
                updated_at=excluded.updated_at
            """,
            (
                session.session_id,
                session.state.value,
                ticket.ticket_id,
                session_json,
                session.created_at.isoformat(),
                session.updated_at.isoformat(),
            ),
        )
        self.conn.execute(
            """
            INSERT INTO tickets (
                ticket_id, session_id, status, customer_name, service, preferred_time,
                submitted_to_openclaw, openclaw_response_json, payload_json, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(ticket_id) DO UPDATE SET
                session_id=excluded.session_id,
                status=excluded.status,
                customer_name=excluded.customer_name,
                service=excluded.service,
                preferred_time=excluded.preferred_time,
                submitted_to_openclaw=excluded.submitted_to_openclaw,
                openclaw_response_json=excluded.openclaw_response_json,
                payload_json=excluded.payload_json,
                updated_at=excluded.updated_at
            """,
            (
                ticket.ticket_id,
                session.session_id,
                ticket.status,
                ticket.customer.name,
                ticket.request.service,
                ticket.request.preferred_time,
                1 if session.submitted_to_openclaw else 0,
                json.dumps(session.openclaw_response) if session.openclaw_response is not None else None,
                ticket_json,
                ticket.created_at.isoformat(),
                ticket.updated_at.isoformat(),
            ),
        )
        self.conn.commit()

    def get_session(self, session_id: str) -> Optional[IntakeSession]:
        row = self.conn.execute(
            "SELECT payload_json FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
        if not row:
            return None
        return IntakeSession.model_validate(json.loads(row["payload_json"]))

    def list_tickets(self, limit: int = 50) -> list[TicketSummary]:
        rows = self.conn.execute(
            """
            SELECT ticket_id, session_id, status, customer_name, service, preferred_time,
                   submitted_to_openclaw, created_at, updated_at
            FROM tickets
            ORDER BY updated_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [
            TicketSummary(
                ticket_id=row["ticket_id"],
                session_id=row["session_id"],
                status=row["status"],
                customer_name=row["customer_name"],
                service=row["service"],
                preferred_time=row["preferred_time"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                submitted_to_openclaw=bool(row["submitted_to_openclaw"]),
            )
            for row in rows
        ]

    def get_ticket_detail(self, ticket_id: str) -> Optional[TicketDetail]:
        row = self.conn.execute(
            """
            SELECT session_id, payload_json, submitted_to_openclaw, openclaw_response_json
            FROM tickets
            WHERE ticket_id = ?
            """,
            (ticket_id,),
        ).fetchone()
        if not row:
            return None
        response = json.loads(row["openclaw_response_json"]) if row["openclaw_response_json"] else None
        from .models import Ticket

        return TicketDetail(
            session_id=row["session_id"],
            ticket=Ticket.model_validate(json.loads(row["payload_json"])),
            submitted_to_openclaw=bool(row["submitted_to_openclaw"]),
            openclaw_response=response,
        )
