from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Annotated

from fastapi import Depends, FastAPI

from .config import Settings, get_settings
from .database import SessionRepository, get_connection, init_db
from .models import (
    HealthResponse,
    StartSessionRequest,
    StartSessionResponse,
    SubmitSessionResponse,
    TicketDetail,
    TicketSummary,
    UserTurnRequest,
    UserTurnResponse,
)
from .service import IntakeService


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    conn = get_connection(settings.database_path)
    init_db(conn)
    app.state.db_conn = conn
    app.state.repository = SessionRepository(conn)
    app.state.service = IntakeService(app.state.repository, settings)
    yield
    conn.close()


app = FastAPI(title="Intake Service", version="0.4.0", lifespan=lifespan)


def get_repository() -> SessionRepository:
    return app.state.repository


def get_service() -> IntakeService:
    return app.state.service


def get_app_settings() -> Settings:
    return get_settings()


RepoDep = Annotated[SessionRepository, Depends(get_repository)]
ServiceDep = Annotated[IntakeService, Depends(get_service)]
SettingsDep = Annotated[Settings, Depends(get_app_settings)]


@app.get("/health", response_model=HealthResponse)
def health(settings: SettingsDep) -> HealthResponse:
    return HealthResponse(status="ok", app_name=settings.app_name, db_path=settings.database_path)


@app.post("/sessions", response_model=StartSessionResponse)
def start_session(body: StartSessionRequest, service: ServiceDep) -> StartSessionResponse:
    session = service.start_session(phone=body.phone, channel=body.channel)
    return StartSessionResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=session.last_assistant_message or service.state_machine.start_message(),
        ticket=session.ticket,
    )


@app.get("/sessions/{session_id}", response_model=UserTurnResponse)
def get_session(session_id: str, service: ServiceDep) -> UserTurnResponse:
    session = service.get_session_or_404(session_id)
    return UserTurnResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=session.last_assistant_message or service.state_machine.start_message(),
        ticket=session.ticket,
        submitted_to_openclaw=session.submitted_to_openclaw,
        openclaw_response=session.openclaw_response,
    )


@app.post("/sessions/{session_id}/turn", response_model=UserTurnResponse)
async def user_turn(session_id: str, body: UserTurnRequest, service: ServiceDep) -> UserTurnResponse:
    session = await service.process_turn(session_id, body.user_input)
    return UserTurnResponse(
        session_id=session.session_id,
        state=session.state,
        assistant_message=session.last_assistant_message,
        ticket=session.ticket,
        submitted_to_openclaw=session.submitted_to_openclaw,
        openclaw_response=session.openclaw_response,
    )


@app.post("/sessions/{session_id}/submit", response_model=SubmitSessionResponse)
async def submit_session(session_id: str, service: ServiceDep) -> SubmitSessionResponse:
    session, message = await service.submit_session(session_id)
    return SubmitSessionResponse(
        session_id=session.session_id,
        state=session.state,
        ticket=session.ticket,
        submitted_to_openclaw=session.submitted_to_openclaw,
        openclaw_response=session.openclaw_response,
        message=message,
    )


@app.get("/tickets", response_model=list[TicketSummary])
def list_tickets(repository: RepoDep, limit: int = 50) -> list[TicketSummary]:
    return repository.list_tickets(limit=limit)


@app.get("/tickets/{ticket_id}", response_model=TicketDetail)
def get_ticket(ticket_id: str, repository: RepoDep) -> TicketDetail:
    detail = repository.get_ticket_detail(ticket_id)
    if not detail:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="Ticket not found")
    return detail
