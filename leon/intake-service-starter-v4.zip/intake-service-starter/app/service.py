from __future__ import annotations

from fastapi import HTTPException

from .config import Settings
from .database import SessionRepository
from .models import IntakeSession, SessionState
from .opencaw_adapter import submit_ticket
from .state_machine import IntakeStateMachine


class IntakeService:
    def __init__(self, repository: SessionRepository, settings: Settings):
        self.repository = repository
        self.settings = settings
        self.state_machine = IntakeStateMachine()

    def start_session(self, phone: str | None = None, channel: str = "phone") -> IntakeSession:
        session = IntakeSession()
        session.ticket.channel = channel
        if phone:
            session.ticket.customer.phone = phone
        message = self.state_machine.start_message()
        session.state = SessionState.COLLECT_NAME
        session.last_assistant_message = message
        session.touch()
        self.repository.save_session(session)
        return session

    def get_session_or_404(self, session_id: str) -> IntakeSession:
        session = self.repository.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        return session

    async def process_turn(self, session_id: str, user_input: str) -> IntakeSession:
        session = self.get_session_or_404(session_id)
        message = self.state_machine.handle_turn(session, user_input)
        session.last_assistant_message = message
        self.repository.save_session(session)
        return session

    async def submit_session(self, session_id: str) -> tuple[IntakeSession, str]:
        session = self.get_session_or_404(session_id)
        if session.state != SessionState.SUBMITTED:
            raise HTTPException(status_code=400, detail="Session must reach submitted state before backend submission")
        if session.submitted_to_openclaw:
            self.repository.save_session(session)
            return session, "Ticket was already submitted to OpenClaw."

        submission_result = await submit_ticket(session.ticket, self.settings)
        session.submitted_to_openclaw = submission_result.submitted
        session.openclaw_response = submission_result.response
        session.ticket.status = "submitted_to_openclaw" if submission_result.submitted else "confirmed_local"
        session.last_assistant_message = (
            "Thanks. Your request has been submitted. We'll follow up with the next step shortly."
        )
        session.touch()
        self.repository.save_session(session)
        if submission_result.submitted:
            return session, "Ticket submitted to OpenClaw."
        return session, "OpenClaw disabled; ticket confirmed locally."
