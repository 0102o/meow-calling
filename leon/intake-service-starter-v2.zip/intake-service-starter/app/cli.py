from __future__ import annotations

import asyncio
import json

from .config import get_settings
from .models import IntakeSession, SessionState
from .opencaw_adapter import submit_ticket
from .state_machine import IntakeStateMachine

HELP_TEXT = """Commands:
  /show   Show current ticket JSON
  /state  Show current state
  /restart Start a new session
  /quit   Exit
"""


def new_session(phone: str | None = None) -> IntakeSession:
    session = IntakeSession()
    if phone:
        session.ticket.customer.phone = phone
    session.state = SessionState.COLLECT_NAME
    return session


async def maybe_submit(session: IntakeSession) -> str:
    settings = get_settings()
    result = await submit_ticket(session.ticket, settings)
    session.submitted_to_openclaw = result.submitted
    session.openclaw_response = result.response
    session.ticket.status = "submitted_to_openclaw" if result.submitted else "confirmed_local"
    return (
        "\n[submission] Ticket submitted to OpenClaw."
        if result.submitted
        else "\n[submission] OpenClaw disabled; ticket confirmed locally."
    )


async def run_cli() -> None:
    sm = IntakeStateMachine()
    print("Intake Service CLI v0")
    print("Type /quit to exit. Type /show to inspect the current ticket.")
    print()

    phone = input("Optional customer phone (press Enter to skip): ").strip() or None
    session = new_session(phone)
    opening = sm.start_message()
    session.last_assistant_message = opening
    print(f"\nAI: {opening}")

    while True:
        user_input = input("You: ").strip()

        if not user_input:
            print("AI: I didn't catch that. Could you say that one more time?")
            continue

        if user_input == "/quit":
            print("Exiting.")
            return
        if user_input == "/help":
            print(HELP_TEXT)
            continue
        if user_input == "/show":
            print(json.dumps(session.ticket.model_dump(mode="json"), indent=2))
            continue
        if user_input == "/state":
            print(f"Current state: {session.state.value}")
            continue
        if user_input == "/restart":
            session = new_session(phone)
            opening = sm.start_message()
            session.last_assistant_message = opening
            print(f"\nAI: {opening}")
            continue

        message = sm.handle_turn(session, user_input)
        session.last_assistant_message = message
        print(f"AI: {message}")

        if session.state == SessionState.SUBMITTED and not session.submitted_to_openclaw:
            status_text = await maybe_submit(session)
            print(status_text)
            print("AI: Thanks. Your request has been submitted. We'll follow up with the next step shortly.")
            print("\nFinal ticket:")
            print(json.dumps(session.ticket.model_dump(mode="json"), indent=2))
            print("\nYou can type /restart to run another intake, or /quit to leave.")


if __name__ == "__main__":
    asyncio.run(run_cli())
