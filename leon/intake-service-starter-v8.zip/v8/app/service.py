
from __future__ import annotations

import re
from typing import Any

from fastapi import HTTPException

from .config import Settings
from .database import SessionRepository
from .extraction import extract_candidate_fields, sanitize_notes
from .models import (
    CandidateFields,
    ConversationContract,
    ConversationMessage,
    FollowupAction,
    IntakeSession,
    ProposeTicketRequest,
    ProposeTicketResponse,
    SessionState,
    SuggestFromTextResponse,
    TelephonyEvent,
)
from .openclaw_adapter import submit_ticket
from .state_machine import IntakeStateMachine, PROMPT_LIBRARY


class IntakeService:
    def __init__(self, repository: SessionRepository, settings: Settings):
        self.repository = repository
        self.settings = settings
        self.state_machine = IntakeStateMachine()

    def start_session(self, phone: str | None = None, channel: str = "phone") -> IntakeSession:
        session = IntakeSession()
        session.ticket.channel = channel
        if phone:
            session.ticket.customer.phone = phone
        session.state = self.state_machine.resolve_state(session)
        message = self.state_machine.start_message() if session.state == SessionState.COLLECT_NAME else self.state_machine.message_for_state(session)
        session.last_assistant_message = message
        session.transcript.append(ConversationMessage(role="assistant", content=message))
        session.touch()
        self.repository.save_session(session)
        return session

    def get_session_or_404(self, session_id: str) -> IntakeSession:
        session = self.repository.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        return session

    def build_contract(self, session: IntakeSession) -> ConversationContract:
        state = self.state_machine.resolve_state(session)
        prompt_id = self.state_machine.prompt_id_for_state(state)
        ticket = session.ticket
        suggested_channel_switch = None
        if ticket.channel == "phone" and (state == SessionState.COLLECT_NOTES or state == SessionState.CONFIRMATION):
            suggested_channel_switch = "sms_optional"
        return ConversationContract(
            session_id=session.session_id,
            state=state,
            channel=ticket.channel,
            current_field=self.state_machine.current_field(session),
            required_fields=self.state_machine.required_fields(),
            missing_fields=self.state_machine.missing_fields(ticket),
            next_prompt=self.state_machine.suggested_next_question(session),
            prompt_id=prompt_id,
            play_audio_id=self.state_machine.play_audio_id_for_session(session),
            allow_submit=state == SessionState.SUBMITTED and not session.submitted_to_openclaw,
            needs_confirmation=state == SessionState.CONFIRMATION,
            draft_form=CandidateFields(
                customer_name=ticket.customer.name,
                phone=ticket.customer.phone,
                service=ticket.request.service,
                preferred_time=ticket.request.preferred_time,
                notes=ticket.request.notes,
            ),
            authoritative_ticket=ticket,
            confirmation_summary=self.state_machine.confirmation_summary(ticket) if state in {SessionState.CONFIRMATION, SessionState.SUBMITTED} else None,
            suggested_channel_switch=suggested_channel_switch,
        )

    async def process_turn(self, session_id: str, user_input: str) -> IntakeSession:
        session = self.get_session_or_404(session_id)
        session.transcript.append(ConversationMessage(role="user", content=user_input))
        message = self.state_machine.handle_turn(session, user_input)
        session.last_assistant_message = message
        session.transcript.append(ConversationMessage(role="assistant", content=message))
        self.repository.save_session(session)
        return session

    def suggest_from_text(self, session_id: str, text: str) -> SuggestFromTextResponse:
        session = self.get_session_or_404(session_id)
        candidates = extract_candidate_fields(text)
        preview = session.model_copy(deep=True)
        self._apply_candidate_updates(preview, candidates, strict=False)
        preview.state = self.state_machine.resolve_state(preview)
        return SuggestFromTextResponse(
            session_id=session.session_id,
            source_text=text,
            candidate_fields=candidates,
            missing_fields=self.state_machine.missing_fields(preview.ticket),
            suggested_next_question=self.state_machine.suggested_next_question(preview),
            preview_ticket=preview.ticket,
        )

    def propose_ticket_update(self, session_id: str, proposal: ProposeTicketRequest) -> ProposeTicketResponse:
        session = self.get_session_or_404(session_id)
        accepted, rejected = self._apply_candidate_updates(session, CandidateFields(**proposal.model_dump(exclude={"source", "raw_text", "auto_advance"})))
        if proposal.raw_text:
            session.transcript.append(
                ConversationMessage(role="system", content=f"Frontend AI draft source: {proposal.raw_text[:200]}")
            )
        if accepted:
            session.transcript.append(
                ConversationMessage(role="system", content=f"Applied draft fields from {proposal.source}: {accepted}")
            )
        if rejected:
            session.transcript.append(
                ConversationMessage(role="system", content=f"Rejected draft fields from {proposal.source}: {rejected}")
            )
        if proposal.auto_advance:
            session.last_assistant_message = self.state_machine.refresh_after_ticket_change(session)
            session.transcript.append(ConversationMessage(role="assistant", content=session.last_assistant_message))
        session.ticket.status = self._local_ticket_status_for_state(session.state)
        session.touch()
        self.repository.save_session(session)
        return ProposeTicketResponse(
            session_id=session.session_id,
            state=session.state,
            ticket=session.ticket,
            accepted_updates=accepted,
            rejected_updates=rejected,
            missing_fields=self.state_machine.missing_fields(session.ticket),
            suggested_next_question=self.state_machine.suggested_next_question(session),
            source=proposal.source,
            contract=self.build_contract(session),
        )

    async def submit_session(self, session_id: str) -> tuple[IntakeSession, str]:
        session = self.get_session_or_404(session_id)
        if session.state != SessionState.SUBMITTED:
            raise HTTPException(status_code=400, detail="Session must reach submitted state before backend submission")
        if session.submitted_to_openclaw:
            self.repository.save_session(session)
            return session, "Ticket was already submitted to OpenClaw."

        submission_result = await submit_ticket(session.ticket, self.settings)
        session.submitted_to_openclaw = submission_result.submitted
        session.openclaw_response = submission_result.response
        session.ticket.status = "submitted_to_openclaw" if submission_result.submitted else "confirmed_local"
        session.last_assistant_message = (
            "Thanks. Your request has been submitted. We'll follow up with the next step shortly."
        )
        session.transcript.append(
            ConversationMessage(
                role="system",
                content=f"OpenClaw submission result: {session.openclaw_response or {'status': 'local_only'}}",
            )
        )
        session.transcript.append(ConversationMessage(role="assistant", content=session.last_assistant_message))
        session.touch()
        self.repository.save_session(session)
        if submission_result.submitted:
            return session, "Ticket submitted to OpenClaw."
        return session, "OpenClaw disabled; ticket confirmed locally."

    async def handle_voice_inbound(self, payload: dict[str, Any]) -> dict[str, Any]:
        from_number = normalize_phone(payload.get("From"))
        session = self.repository.find_latest_session_by_phone(from_number) if from_number else None
        if not session or session.submitted_to_openclaw:
            session = self.start_session(phone=from_number, channel="phone")
        call_sid = payload.get("CallSid")
        self.repository.save_event(
            TelephonyEvent(
                source="twilio_voice",
                event_type="voice_inbound",
                external_id=call_sid,
                session_id=session.session_id,
                payload=payload,
            )
        )
        contract = self.build_contract(session)
        return {
            "session_id": session.session_id,
            "say": contract.next_prompt,
            "prompt_id": contract.prompt_id,
            "play_audio_id": contract.play_audio_id,
            "gather": True,
        }

    async def handle_voice_status(self, payload: dict[str, Any]) -> dict[str, Any]:
        call_sid = payload.get("CallSid")
        call_status = (payload.get("CallStatus") or payload.get("CallStatusCallbackEvent") or "").lower()
        session_id = self.repository.find_session_id_by_external_id(call_sid) if call_sid else None
        session = self.get_session_or_404(session_id) if session_id else None
        self.repository.save_event(
            TelephonyEvent(
                source="twilio_voice",
                event_type="voice_status",
                external_id=call_sid,
                session_id=session_id,
                payload=payload,
            )
        )
        created_action = None
        if session and call_status in {"no-answer", "busy", "failed", "canceled"}:
            created_action = self._create_missed_call_followup(
                session=session,
                reason=f"Missed call status: {call_status}",
                destination=session.ticket.customer.phone,
            )
        return {
            "ok": True,
            "session_id": session_id,
            "call_status": call_status,
            "followup_action": created_action.model_dump(mode="json") if created_action else None,
        }

    async def handle_sms_inbound(self, payload: dict[str, Any]) -> dict[str, Any]:
        from_number = normalize_phone(payload.get("From"))
        body = (payload.get("Body") or "").strip()
        session = self.repository.find_latest_session_by_phone(from_number) if from_number else None
        if not session or session.submitted_to_openclaw:
            session = self.start_session(phone=from_number, channel="sms")
        message_sid = payload.get("MessageSid")
        self.repository.save_event(
            TelephonyEvent(
                source="twilio_sms",
                event_type="sms_inbound",
                external_id=message_sid,
                session_id=session.session_id,
                payload=payload,
            )
        )
        if body:
            session = await self.process_turn(session.session_id, body)
        contract = self.build_contract(session)
        return {
            "session_id": session.session_id,
            "reply": contract.next_prompt,
            "prompt_id": contract.prompt_id,
            "state": session.state.value,
            "allow_submit": contract.allow_submit,
        }

    def _apply_candidate_updates(
        self,
        session: IntakeSession,
        candidates: CandidateFields,
        strict: bool = True,
    ) -> tuple[dict[str, str], dict[str, str]]:
        accepted: dict[str, str] = {}
        rejected: dict[str, str] = {}
        updates = candidates.as_update_dict()
        for field, value in updates.items():
            cleaned = self._validate_field(field, value)
            if cleaned is None:
                rejected[field] = f"Invalid value: {value!r}"
                continue
            if field == "customer_name":
                session.ticket.customer.name = cleaned
            elif field == "phone":
                session.ticket.customer.phone = cleaned
            elif field == "service":
                session.ticket.request.service = cleaned
            elif field == "preferred_time":
                session.ticket.request.preferred_time = cleaned
            elif field == "notes":
                session.ticket.request.notes = cleaned
            accepted[field] = cleaned
        if strict and not accepted and updates:
            session.last_assistant_message = "I couldn't safely apply those draft fields."
        return accepted, rejected

    def _validate_field(self, field: str, value: str) -> str | None:
        raw = (value or "").strip()
        if field == "customer_name":
            if 1 <= len(raw) <= 80 and re.fullmatch(r"[A-Za-z][A-Za-z\-\s']*", raw):
                return " ".join(part.capitalize() for part in raw.split())
            return None
        if field == "phone":
            return normalize_phone(raw)
        if field == "service":
            if 1 <= len(raw) <= 80:
                return raw.lower()
            return None
        if field == "preferred_time":
            if 1 <= len(raw) <= 80:
                return raw.lower()
            return None
        if field == "notes":
            if raw.lower() in {"no", "none", "nope", "nothing", "thats all", "that's all"}:
                return ""
            return sanitize_notes(raw)
        return None

    def _create_missed_call_followup(self, session: IntakeSession, reason: str, destination: str | None) -> FollowupAction:
        action = FollowupAction(
            session_id=session.session_id,
            ticket_id=session.ticket.ticket_id,
            action_type="sms_followup",
            channel="sms",
            destination=destination,
            reason=reason,
            payload={
                "suggested_message": "Sorry we missed your call. Reply here to continue your booking request.",
                "policy": "missed_call_recovery",
            },
        )
        self.repository.save_followup_action(action)
        session.transcript.append(ConversationMessage(role="system", content=f"Created follow-up action: {action.action_type} ({reason})"))
        session.touch()
        self.repository.save_session(session)
        return action

    def _local_ticket_status_for_state(self, state: SessionState) -> str:
        if state == SessionState.SUBMITTED:
            return "confirmed"
        if state == SessionState.CONFIRMATION:
            return "ready_for_confirmation"
        return "draft"


def normalize_phone(value: str | None) -> str | None:
    if not value:
        return None
    digits = re.sub(r"\D", "", value)
    if len(digits) == 10:
        return f"+1{digits}"
    if 7 <= len(digits) <= 15:
        return f"+{digits}"
    return None
