# Intake Service Starter v5

A small FastAPI starter for the first phase of your AI receptionist MVP.

## What this does now

- Starts an intake session
- Collects required fields with a simple state machine
- Builds a structured ticket
- Confirms details before submission
- Persists sessions and tickets in SQLite
- Exposes ticket lookup endpoints for a dashboard
- Serves a simple operator dashboard at `/dashboard`
- Optionally forwards the confirmed ticket to an OpenClaw webhook adapter

## File layout

```text
app/
  config.py
  database.py
  extraction.py
  main.py
  models.py
  openclaw_adapter.py
  service.py
  state_machine.py
  templates/
    dashboard.html
configs/
  openclaw/
    openclaw.intake.example.json5
    intake-hooks-skill/
      SKILL.md
scripts/
  run_cli.sh
  run_dev.sh
requirements.txt
.env.example
data/
```

## Quick start

```bash
cd intake-service-starter
cp .env.example .env
./scripts/run_dev.sh
```

Open the operator dashboard at:

```text
http://127.0.0.1:8000/dashboard
```

API docs stay at:

```text
http://127.0.0.1:8000/docs
```

## Run in the terminal

```bash
./scripts/run_cli.sh
```

CLI helpers:

- `/show` show the current ticket JSON
- `/state` show the current state
- `/submit` submit after confirmation
- `/restart` start a new intake session
- `/quit` exit the CLI

## API flow

### 1. Start a session

```bash
curl -X POST http://127.0.0.1:8000/sessions \
  -H 'Content-Type: application/json' \
  -d '{"phone":"+14155551234","channel":"phone"}'
```

### 2. Provide turns until confirmation is complete

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/turn \
  -H 'Content-Type: application/json' \
  -d '{"user_input":"Hi, my name is Connor"}'
```

### 3. Submit the confirmed ticket

```bash
curl -X POST http://127.0.0.1:8000/sessions/SESSION_ID/submit
```

### 4. List tickets for dashboard use

```bash
curl http://127.0.0.1:8000/tickets
```

### 5. Inspect a single ticket

```bash
curl http://127.0.0.1:8000/tickets/TICKET_ID
```

## How OpenClaw fits in this starter

Recommended flow:

```text
CLI / dashboard / future phone webhook
                ↓
          intake backend
                ↓
            SQLite store
                ↓
        POST /hooks/agent
                ↓
      dedicated OpenClaw agent
```

Use the sample config in `configs/openclaw/openclaw.intake.example.json5` as a starting point.

The starter expects these `.env` values when you are ready to forward to OpenClaw:

```env
OPENCLAW_ENABLED=true
OPENCLAW_HOOK_URL=http://127.0.0.1:8080/hooks/agent
OPENCLAW_HOOK_TOKEN=your-secret
OPENCLAW_AGENT_ID=intake-hooks
```

## Suggested next steps

1. Add business records and route tickets by business ID
2. Add a real telephony webhook layer
3. Add SMS follow-up and missed-call recovery
4. Move OpenClaw forwarding behind a retry queue
5. Add authentication to the dashboard before any remote exposure
